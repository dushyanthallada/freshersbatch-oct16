package mvc.quest12;

public class LowBalanceException extends Exception {
	
}
