package mvc.quest12;

public class AccountNotFoundException extends Exception {

}
